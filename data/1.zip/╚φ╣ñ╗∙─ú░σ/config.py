class Config(object):
    MYSQL_DATABASE_USER = 'root'
    MYSQL_DATABASE_PASSWORD = 'password'
    MYSQL_DATABASE_DB = 'onlinepayment'
    MYSQL_DATABASE_HOST = 'localhost'
